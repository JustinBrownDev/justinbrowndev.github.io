# JWEB Active Source Registry v1

Grounded source candidates for TVs, radios, jukeboxes, tickers, terminals, scientific instruments, warning systems, and dynamic signage.

## Strongest immediate keepers

- **Al Jazeera English Live** — use the official verified YouTube live stream as an embed candidate. Do not frame aljazeera.com itself; current Al Jazeera terms prohibit framing. Raw HLS/video-texture playback is *not* claimed.
- **VOA RSS** — unusually attractive for text/audio because VOA says material produced exclusively by VOA is public domain; still exclude third-party licensed media.
- **NWS alerts** — structured JSON-LD/CAP/Atom with explicit refresh guidance.
- **USGS earthquake GeoJSON** — purpose-built programmatic real-time feed.
- **NOAA SWPC** — tiny live JSON products for solar wind, Kp, alerts, NOAA scales, aurora, etc.
- **Aviation Weather** — excellent METAR/TAF/PIREP/SIGMET data; official docs say CORS is disabled, so cache/proxy it.
- **SEC EDGAR** — real-time filing/XBRL metadata; official docs say CORS is disabled, so cache/proxy it.
- **CISA KEV** — canonical JSON plus an official GitHub mirror.
- **Crossref** — huge scholarly metadata corpus; cache and use the polite pool.
- **LibriVox** — public-domain audio; ideal for weird jukebox/radio/listening-booth content.
- **NOAA CO-OPS** — real tide/water/current/weather observations for harbor and dock instruments.
- **Treasury Debt to the Penny** — perfect literal financial tickers.
- **JWEB runtime telemetry** — zero-network live data and a natural fallback for active displays.

## Important architectural rule

The asset should never contain a provider URL. Assets expose capabilities such as `media.video`, `audio.spatial`, `data.feed`, `text.dynamic`, `light.emissive`, `motion.rotary`. A provider adapter resolves those capabilities later.

Every external source should have a cached/offline fallback. Never make world generation or traversal wait on a feed.
